import Fruit from '../models/Fruit';

const fruits = [
    new Fruit("Citron","#FFCC00"),
    new Fruit("Peche", "#F44336"),
    new Fruit("Fraise", "#E53935"),
];

export default fruits;